import { Component, OnInit } from '@angular/core';
import { AclBaseService } from '../../shared/services/app.service';
import { AclCTAService } from '../../shared/components/aclcta/acl-cta.service';
import { ACLModel } from '../../shared/models/acl.model';

export const DATA_SOURCE:Array<object> = [
  {name:'Default', url:'./assets/data/datasource1.json'},
  {name:'Default - Disabled', url:'./assets/data/datasource2.json'},
  {name:'Background', url:'./assets/data/datasource3.json'},
  {name:'Background - Disabled', url:'./assets/data/datasource4.json'},
  {name:'Primary', url:'./assets/data/datasource5.json'},
  {name:'Primary - Disabled', url:'./assets/data/datasource6.json'},
  {name:'Primary Icon', url:'./assets/data/datasource7.json'},
  {name:'Primary Icon - Disabled', url:'./assets/data/datasource8.json'}
];

@Component({
  selector: 'component-render-view',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {
  title:string;
  datasource:Array<object>;
  selDatasource:any;

  constructor(private appService:AclBaseService, private aclService:AclCTAService, private model:ACLModel) {
    this.title = 'ACL CTA Component';
    this.datasource = DATA_SOURCE;
    this.selDatasource = this.datasource[0];
  }

  ngOnInit() {
    this.getDatasource();
  }

  initData() {
    this.model = this.aclService.dataMapper();
  }

  getDatasource() {
    this.appService.getCTAComponentData(this.selDatasource.url).subscribe(
      response => {
        this.aclService.handleResponse(response);
        this.initData();
      }
    );
  }

  showWelcome() {
    console.log('Hi, Welcome!!');
  }
}
