// Angular Modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// Application Services and Models
import { AclCTAService } from './shared/components/aclcta/acl-cta.service';
import { AclBaseService } from './shared/services/app.service';
import { ACLModel } from './shared/models/acl.model';

// Application Components
import { AppComponent } from './app.component';
import { ACLCTAComponent } from './shared/components/aclcta/acl-cta.component';
import { LandingComponent } from './page/landing/landing.component';

@NgModule({
  declarations: [
    AppComponent,
    ACLCTAComponent,
    LandingComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [AclBaseService, AclCTAService, ACLModel],
  bootstrap: [AppComponent]
})
export class AppModule { }
