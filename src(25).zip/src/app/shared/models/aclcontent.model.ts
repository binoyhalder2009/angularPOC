export interface ACLContent {
    text:string;
    link:string;
    target:string;
}