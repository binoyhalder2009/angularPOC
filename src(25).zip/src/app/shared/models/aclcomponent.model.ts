export interface ACLComonent {
    id: string;
    name:string;
    version: string;
    variant: string;
    state: string;
    schema: object;
}