import { ACLComonent } from "./aclcomponent.model";
import { ACLContent } from "./aclcontent.model";

export class ACLModel {
    component:ACLComonent;
    content:Array<ACLContent>;

    constructor() {
        this.component = {id:'aclcta', name:'CTA', version:'1.0', variant:'default', state:'disabled', schema:{}};
        this.content = [{text:'Check Other Stores', link:'www.homedepot.ca', target:'_blank'}];
    }
};