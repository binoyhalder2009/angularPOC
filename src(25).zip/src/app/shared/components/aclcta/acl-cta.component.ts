import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AclCTAService } from './acl-cta.service';
import { ACLModel } from '../../models/acl.model';

@Component({
  selector: 'acl-cta',
  templateUrl: './acl-cta.component.html',
  styleUrls: ['./acl-cta.component.css']
})
export class ACLCTAComponent implements OnInit {
  compModel:ACLModel;

  @Output() ctaClick:EventEmitter<any> = new EventEmitter<any>();

  constructor(private _service:AclCTAService) { }

  ngOnInit() {
    this.compModel = this._service.getComponentModel();
  }

  fireClickEvent() {
    this.ctaClick.emit();
  }
}
