import { Injectable } from '@angular/core';
import { ACLModel } from '../../models/acl.model';

@Injectable()
export class AclCTAService {
  response:any = {};

  constructor(public model:ACLModel) {} 

  dataMapper():ACLModel {
    this.model.component.id = this.response.id;
    this.model.component.name = this.response.name;
    this.model.component.state = this.response.state;
    this.model.component.variant = this.response.variant;
    this.model.component.version = this.response.version;
    
    this.model.content[0].link = this.response.content[0].link;
    this.model.content[0].target = this.response.content[0].target;
    this.model.content[0].text = this.response.content[0].text;

    return this.model;
  }

  handleResponse(res) {
    this.response = res;
  }

  getComponentModel() {
    return this.model;
  }
}
