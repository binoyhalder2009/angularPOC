import { Content2 } from './acl-image-content2.model';

export interface ACLImage2 {
    id:string;
    name:string;
    version:string;
    variant:string;
    state:string;
    content:Content2;
}