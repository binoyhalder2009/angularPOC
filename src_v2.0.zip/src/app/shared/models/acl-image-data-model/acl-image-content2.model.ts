export interface Content2 {
    src:string;
    class:string;
    alt:string;
}