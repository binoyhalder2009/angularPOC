export const AppConfig = {
    API_ENDPOINT: './app/core/stubs/data/mockJsonAclImageDetails2.json',
    ACL_IMAGE: 'ACL Image Component',
    ACL_BANNER: 'ACL Banner Component',
    API_ENDPOINT_IMAGE_LIST: './app/core/stubs/acl-image-json-data-stub.ts'
}

