import { Injectable } from '@angular/core';
import { ACLImage } from '../../../shared/models/acl-image-data-model/acl-image.model';
import { Content } from '../../../shared/models/acl-image-data-model/acl-image-content.model';
import { AppConfig } from '../app-config/app.config';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { AclBannerDataMapperService } from '../../data-mapper/acl-banner-data-mapper/acl-banner-data-mapper.service'
import { ACLBanner } from '../../../shared/models';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class AclBannerService {

  constructor(private http: HttpClient, private bannerDateMapper: AclBannerDataMapperService) {
  }

  getAclBanners(): ACLBanner[]{
    return this.bannerDateMapper.getBanners();
  }
}
