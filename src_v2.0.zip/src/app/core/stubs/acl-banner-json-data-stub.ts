export const mockBanners = {
    'bannerList': [
        {
            'typeId': 'SC_HEADER_BANNER',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': '',
                'state': '',
                'content': {
                    'src': 'assets/images/homedepot_logo.jpg',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        },
        {
            'typeId': 'sc_large_promo1',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': 'product-gallery',
                'state': '',
                'content': {
                    'src': 'assets/images/homepage.png',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        },
        {
            'typeId': 'sc_large_promo2',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': 'product-gallery',
                'state': 'blurred',
                'content': {
                    'src': 'assets/images/homepage.png',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        },
        {
            'typeId': 'sc_small_promo1',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': '',
                'state': '',
                'content': {
                    'src': 'assets/images/homedepot_logo.jpg',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        },
        {
            'typeId': 'sc_small_promo2',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': 'product-gallery',
                'state': 'blurred',
                'content': {
                    'src': 'assets/images/homepage.png',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        },
        {
            'typeId': 'sc_small_promo3',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': 'product-gallery',
                'state': '',
                'content': {
                    'src': 'assets/images/homepage.png',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        },
        {
            'typeId': 'sc_small_promo4',
            'name': 'SC_HEADER_BANNER',
            'version': 'SC_HEADER_BANNER',
            'variantId': 'SC_HEADER_BANNER',
            'variant': 'SC_HEADER_BANNER',
            'stateId': 'SC_HEADER_BANNER',
            'state': 'SC_HEADER_BANNER',
            'image': {
                'id': 'acl-image',
                'name': 'MAIN TITLE',
                'version': '1.0',
                'variant': 'product-gallery',
                'state': 'blurred',
                'content': {
                    'src': 'assets/images/homepage.png',
                    'class': '',
                    'alt': ''
                }
            },
            'button': {
                'class': ''
            }
        }
    ]
};