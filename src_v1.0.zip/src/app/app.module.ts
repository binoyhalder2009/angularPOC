import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './components/app.component';
import { ACLImageComponent } from './shared/components/acl-image/acl-image.component';
import { AclImageService } from './core/services/acl-image-service/acl-image.service';
import { AclImageDataMapperService } from './shared/data-mapper/acl-image-data-mapper/acl-image-data-mapper.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ACLImageComponent
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [AclImageService, AclImageDataMapperService],
  bootstrap: [AppComponent]
})
export class AppModule { }
