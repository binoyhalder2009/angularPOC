import { Component, OnInit } from '@angular/core';
import { AclImageService } from '../core/services/acl-image-service/acl-image.service';
import { ACLImage } from '../shared/models/acl-image-data-model/acl-image.model';
import { AppConfig } from '../core/services/app-config/app.config';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: []
})
export class AppComponent implements OnInit{
  title:String;
  aclImage:ACLImage;

  constructor(private aclImageService:AclImageService){ };

  ngOnInit() {
    this.title=AppConfig.ACL_IMAGE;
    this.getAclImage();
  }

  getAclImage() {
    this.aclImageService.getAclImage().subscribe(image => this.aclImage = image);
  }
}