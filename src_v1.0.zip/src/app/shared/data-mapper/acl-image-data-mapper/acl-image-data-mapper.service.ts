import { Injectable } from '@angular/core';
import { ACLImage } from '../../../shared/models/acl-image-data-model/acl-image.model';
import { Content } from '../../../shared/models/acl-image-data-model/acl-image-content.model';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AclImageDataMapperService {

  private aclImageModel:ACLImage;
  private aclContentModel:Content;

  constructor(private http: HttpClient) { }

  getJsonAclImage(data):ACLImage{
    alert("Json Data: "+data);
    this.aclImageModel = new ACLImage();
    this.aclContentModel = new Content();

    //this.getJSON(serviceUrl).subscribe(data => {
      this.aclImageModel.id = data.id;
      this.aclImageModel.name = data.name;
      this.aclImageModel.state = data.state;
      this.aclImageModel.version = data.version;
      this.aclImageModel.variant = data.variant;

      this.aclContentModel.src = data.content.src;
      this.aclContentModel.class = data.content.class;
      this.aclContentModel.alt = data.content.alt;

      this.aclImageModel.content = this.aclContentModel;
    //});
    return this.aclImageModel;
  }

  getJSON(serviceUrl): Observable<any> {
    return this.http.get(serviceUrl)
  }
}
