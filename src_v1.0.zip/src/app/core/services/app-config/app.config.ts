export const AppConfig = {
    API_ENDPOINT: './app/core/stubs/data/mockJsonAclImageDetails2.json',
    ACL_IMAGE: 'ACL Image Component'
}

