export const MockJsonAclImageDetails = {
    "id": "acl-image",
    "name": "ACL Image",
    "version": "1.0",
    "variant": "product-gallery",
    "state": "blurred",
    "content": {
        "src": "assets/images/homepage.png",
        "class": "",
        "alt": ""
    }
};