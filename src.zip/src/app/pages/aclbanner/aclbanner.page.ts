import { Component, OnInit } from '@angular/core';
import { AclBannerService } from '../../core/services/acl-banner-service/acl-banner.service';
import { AppConfig } from '../../core/services/app-config/app.config';
import { ACLBanner } from '../../shared/models';

@Component({
  selector: 'aclbanner-page',
  templateUrl: './aclbanner.page.html',
  styleUrls: ['./aclbanner.page.css']
})
export class AclBannerPage implements OnInit {

  title:String;
  aclBanners:ACLBanner[];

  constructor(private aclBannerService:AclBannerService) {}

  ngOnInit() {
    this.title=AppConfig.ACL_BANNER;
    //For list of images data
    //this.aclBanners = this.aclBannerService.getAclBanners();

    //For list of images data
    this.aclBannerService.getAclMockBanners().subscribe(banners => this.aclBanners = banners);
  }

}
