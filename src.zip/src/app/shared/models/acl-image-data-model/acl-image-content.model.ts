export class Content {
    src:string;
    class:string;
    alt:string;
}