export * from './acl-image-data-model/acl-image.model';
export * from './acl-image-data-model/acl-image-content.model';
export * from './acl-banner-data-model/acl-banner.model';

export * from './acl-image-data-model/acl-image2.model';
export * from './acl-image-data-model/acl-image-content2.model';